const couponData = [
    { code: "SAVE10", discount: 10 },
    { code: "SUMMER20", discount: 20 },
  ];
  
  export default couponData;