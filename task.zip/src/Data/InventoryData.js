const inventoryData = {
    "1": 5,
    "2": 8,
    "3": 3
};
  
export default inventoryData;