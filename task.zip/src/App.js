import './App.css';
import ProductList from './Pages/ProductList';

function App() {
  return (
    <ProductList />
  );
}

export default App;
